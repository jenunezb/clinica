package co.edu.uniquindio.proyecto.dto;

public record MedicoDTOAdmin(
        int codigo,
        String nombre,
        String urlFoto,
        String especialidad
) {
}
