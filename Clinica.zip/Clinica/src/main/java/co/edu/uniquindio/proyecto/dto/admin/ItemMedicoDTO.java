package co.edu.uniquindio.proyecto.dto.admin;

public record ItemMedicoDTO() {
}
