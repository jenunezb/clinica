package co.edu.uniquindio.proyecto.modelo.enums;

public enum EstadoCita {
    ASIGNADA,
    CANCELADA,
    FINALIZADA
}
