package co.edu.uniquindio.proyecto.modelo.enums;

public enum Estado {
    ACTIVO,
    INACTIVO
}
