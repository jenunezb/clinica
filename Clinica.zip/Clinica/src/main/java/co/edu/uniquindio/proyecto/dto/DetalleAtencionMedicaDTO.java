package co.edu.uniquindio.proyecto.dto;

public record DetalleAtencionMedicaDTO(
        int codigoCita
        //el resto de atributos del detalle de la atencion medica
) {
}