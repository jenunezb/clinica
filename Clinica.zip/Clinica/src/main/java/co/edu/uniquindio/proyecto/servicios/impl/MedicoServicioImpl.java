package co.edu.uniquindio.proyecto.servicios.impl;

import co.edu.uniquindio.proyecto.servicios.interfaces.MedicoServicio;
import org.springframework.stereotype.Service;

@Service
public class MedicoServicioImpl implements MedicoServicio {
    @Override
    public void listarCitasPendientes() {

    }

    @Override
    public void atenderCita() {

    }

    @Override
    public void listarCitasPaciente() {

    }

    @Override
    public void agendarDiaLibre() {

    }

    @Override
    public void listarCitasRealizadasMedico() {

    }
}
