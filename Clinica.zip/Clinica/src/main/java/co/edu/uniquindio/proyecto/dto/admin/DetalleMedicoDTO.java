package co.edu.uniquindio.proyecto.dto.admin;

public record DetalleMedicoDTO(
        int codigo,
        String nombre,
        String cedula
        //ETC
) {
}
