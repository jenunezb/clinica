package co.edu.uniquindio.proyecto.dto;

public record LoginDTO(
        String Email,
        String password) {
}
