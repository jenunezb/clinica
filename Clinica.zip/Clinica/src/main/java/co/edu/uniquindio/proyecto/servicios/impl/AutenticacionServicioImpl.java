package co.edu.uniquindio.proyecto.servicios.impl;

import co.edu.uniquindio.proyecto.dto.LoginDTO;
import co.edu.uniquindio.proyecto.servicios.interfaces.AutenticacionServicio;
import org.springframework.stereotype.Service;

@Service
public class AutenticacionServicioImpl implements AutenticacionServicio {
    @Override
    public void login(LoginDTO loginDTO) throws Exception {

    }
}
