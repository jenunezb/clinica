package co.edu.uniquindio.proyecto.dto.paciente;

public record RegistroPQRSDTO() {
}
