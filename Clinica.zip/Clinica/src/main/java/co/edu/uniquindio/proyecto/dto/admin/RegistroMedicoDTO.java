package co.edu.uniquindio.proyecto.dto.admin;

public record RegistroMedicoDTO(
        String nombre,
        String cedula,
        String telefono,
        String ciudad
        //Faltan más cosas pero hay que mirar el mockup
) {
}
