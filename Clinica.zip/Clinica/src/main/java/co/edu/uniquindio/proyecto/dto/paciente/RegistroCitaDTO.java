package co.edu.uniquindio.proyecto.dto.paciente;

public record RegistroCitaDTO(
        int codigoPaciente
        //ETC
) {
}
