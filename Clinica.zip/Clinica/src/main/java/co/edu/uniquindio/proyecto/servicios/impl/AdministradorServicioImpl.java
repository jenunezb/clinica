package co.edu.uniquindio.proyecto.servicios.impl;

import co.edu.uniquindio.proyecto.dto.*;
import co.edu.uniquindio.proyecto.dto.admin.DetalleMedicoDTO;
import co.edu.uniquindio.proyecto.servicios.interfaces.AdministradorServicio;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AdministradorServicioImpl implements AdministradorServicio {


    @Override
    public String crearMedico(MedicoDTO medicoDTO) throws Exception {
        return null;
    }

    @Override
    public String actualizarMedico(int codigo, MedicoDTO medicoDTO) throws Exception {
        return null;
    }

    @Override
    public String eliminarMedico(int codigo) throws Exception {
        return null;
    }

    @Override
    public List<MedicoDTOAdmin> listarMedicos() throws Exception {
        return null;
    }

    @Override
    public DetalleMedicoDTO obtenerMedico(int codigo) throws Exception {
        return null;
    }

    @Override
    public List<itemPQRSDTO> listarPQRS() throws Exception {
        return null;
    }

    @Override
    public DetallePQRSDTO verDetallePQRS(int codigo) throws Exception {
        return null;
    }

    @Override
    public String responderPQRS(int codigo) throws Exception {
        return null;
    }

    @Override
    public PQRSDTOAdmin verDetallePQRS() throws Exception {
        return null;
    }

    @Override
    public int responderPQRS(RegistroRespuestaDTO registroRespuestaDTO) throws Exception {
        return 0;
    }

    @Override
    public List<itemCitaDTO> listarCitas() throws Exception {
        return null;
    }
}
