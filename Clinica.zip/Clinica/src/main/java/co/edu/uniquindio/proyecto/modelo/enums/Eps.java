package co.edu.uniquindio.proyecto.modelo.enums;

public enum Eps {

    SALUD_TOTAL,
    COOMEVA,
    NUEVA_EPS,
    SANITAS,
    SURA

}
