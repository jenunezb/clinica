package co.edu.uniquindio.proyecto.dto;

public record EmailDTO (String para, String asunto,String mensaje){
}
