package co.edu.uniquindio.proyecto.servicios.impl;

import co.edu.uniquindio.proyecto.servicios.interfaces.ImagenServicio;
import org.springframework.stereotype.Service;

@Service
public class ImagenServicioImpl implements ImagenServicio {
}
