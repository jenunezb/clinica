package co.edu.uniquindio.proyecto.servicios.interfaces;

import co.edu.uniquindio.proyecto.dto.*;
import co.edu.uniquindio.proyecto.dto.admin.DetalleMedicoDTO;

import java.util.List;

public interface AdministradorServicio {

    String crearMedico(MedicoDTO medicoDTO)throws Exception;

    String actualizarMedico(int codigo, MedicoDTO medicoDTO)throws Exception;

    String eliminarMedico(int codigo)throws Exception;

    List<MedicoDTOAdmin> listarMedicos()throws Exception;

    DetalleMedicoDTO obtenerMedico(int codigo)throws Exception;

    List<itemPQRSDTO> listarPQRS()throws Exception;

    DetallePQRSDTO verDetallePQRS (int codigo) throws Exception;

    String responderPQRS(int codigo)throws Exception;

    PQRSDTOAdmin verDetallePQRS()throws Exception;

    int responderPQRS (RegistroRespuestaDTO registroRespuestaDTO) throws Exception;

    List<itemCitaDTO> listarCitas()throws Exception;

}
