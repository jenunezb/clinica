package co.edu.uniquindio.proyecto.modelo.enums;

public enum Especialidad {

    CARDIOLOGIA,
    DERMATOLOGIA,
    GINECOLOGIA,
    NEUROLOGIA,
    PEDIATRIA,
    ORTOPEDIA,
    UROLOGIA,
    ONCOLOGIA,
    ENDOCRINOLOGIA,
    OFTALMOLOGIA

}
