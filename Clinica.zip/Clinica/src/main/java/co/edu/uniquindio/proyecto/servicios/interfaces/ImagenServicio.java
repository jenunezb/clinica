package co.edu.uniquindio.proyecto.servicios.interfaces;

public interface ImagenServicio {
}