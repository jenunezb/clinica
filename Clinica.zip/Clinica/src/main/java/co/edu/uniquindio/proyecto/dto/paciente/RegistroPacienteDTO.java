package co.edu.uniquindio.proyecto.dto.paciente;

public record RegistroPacienteDTO(
        //Aqui va toda la información necesaria para registrar un cliente
) {

}